import numpy as np
from matplotlib import pyplot as plt

# method_name can be "linear_scalarization", "mgda", "pareto_mtl", and "pareto_set_learning"
method_name = "linear_scalarization"

# load the ground truth pareto front
pf = np.loadtxt("pareto_front.txt")

# load 2d array in txt
f_value_2d = np.loadtxt("{}.txt".format(method_name))

# reshape the array into 3d
f_value_mat = f_value_2d.reshape(f_value_2d.shape[0], f_value_2d.shape[1] // 2, 2)

# plot and save fig for each frame
filenames = []
for k in range(50):
    
    # static pareto front for each frame
    plt.plot(pf[:,0],pf[:,1])
    
    # scatter plot for point based methods
    if method_name in ["linear_scalarization", "mgda", "pareto_mtl"]:
        plt.scatter(f_value_mat[k,:,0], f_value_mat[k,:,1], c = 'r', s = 80)
    # line plot for pareto set learning
    elif method_name == 'pareto_set_learning':
        plt.plot(f_value_mat[k,:,0], f_value_mat[k,:,1], c = 'r', lw = 4)
    
    plt.xlabel(r'$L_1(\theta)$', fontsize = 12)
    plt.ylabel(r'$L_2(\theta)$', fontsize = 12)
    
    # create file name and append it to a list
    filename = f'{k}.png'
    filenames.append(filename)
    
    # save frame
    plt.savefig(filename)
    plt.close()
    
###----- build gif -----
import imageio.v2 as imageio
with imageio.get_writer('{}.gif'.format(method_name), mode='I') as writer:
    for filename in filenames:
        image = imageio.imread(filename)
        writer.append_data(image)

###----- remove files -----
import os
for filename in set(filenames):
    os.remove(filename)




