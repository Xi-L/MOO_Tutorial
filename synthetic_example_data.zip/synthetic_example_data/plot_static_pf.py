import numpy as np
from matplotlib import pyplot as plt


# load the ground truth pareto front
pf = np.loadtxt("pareto_front.txt")

# plot static pareto front
plt.plot(pf[:,0],pf[:,1])

plt.xlabel(r'$L_1(\theta)$', fontsize = 12)
plt.ylabel(r'$L_2(\theta)$', fontsize = 12)